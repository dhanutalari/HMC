/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chairmanportal;

/**
 *
 * @author student
 */
public class report {

     public String place;
    public String bill;
    public String date;
    /**
     * @return the place
     */
    public String getPlace() {
        return place;
    }

    /**
     * @param place the place to set
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * @return the bill
     */
    public String getBill() {
        return bill;
    }

    /**
     * @param bill the bill to set
     */
    public void setBill(String bill) {
        this.bill = bill;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }
   
}
