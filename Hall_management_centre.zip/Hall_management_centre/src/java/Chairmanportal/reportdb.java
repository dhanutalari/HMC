/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chairmanportal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author student
 */
public class reportdb {
    
    public ArrayList<report> getResultset()
    {
    
        ResultSet rs=null;
        ArrayList<report> result=new ArrayList<report>();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/HMC", "root", "rgukt123");
            PreparedStatement p=co.prepareStatement("select *from updatefa");
            rs=p.executeQuery();
            while(rs.next())
            {
                report rp=new report();
                rp.setPlace(rs.getString("place"));
                rp.setBill(rs.getString("bill"));
                rp.setDate(rs.getString("date"));
                result.add(rp);
            }
            
        }catch(ClassNotFoundException | SQLException e){}
        
        return result;
        
    }
}
