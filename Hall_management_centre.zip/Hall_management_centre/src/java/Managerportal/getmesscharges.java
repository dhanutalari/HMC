/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Managerportal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.http.HttpSession;

/**
 *
 * @author student
 */
public class getmesscharges {

  
    
    public ArrayList<reportdata> getResultset(String mess1) {
         ResultSet rs=null;
       
        ArrayList<reportdata> result=new ArrayList<reportdata>();
         try
        { 
              Class.forName("com.mysql.jdbc.Driver");
             Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/HMC", "root", "rgukt123");
             PreparedStatement ps=co.prepareStatement("select * from allocationdata where mess=?");
            ps.setString(1, mess1);
            rs=ps.executeQuery();
            while(rs.next())
            {
                  reportdata rp=new reportdata();
                    rp.setId(rs.getString("id"));
                    rp.setMess(rs.getString("mess"));
                    rp.setFee(rs.getString("messfee"));
                    rp.setDate(rs.getString("date"));
                    result.add(rp);
            }
          
            
        }catch(ClassNotFoundException | SQLException e){}
        
        return result;
    }
    
}
