/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author student
 */
public class data {
    
    public static boolean validation(String id, String pass)
    {
        boolean status = false;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String url = "jdbc:mysql://localhost:3306/HMC";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "rgukt123";
        
        try
        {
            Class.forName(driver);
            conn=DriverManager.getConnection(url, userName, password);
            pst=conn.prepareCall("select * from studentsignupdata where id=? and pass=?");
            pst.setString(1, id);
            pst.setString(2, pass);
            rs=pst.executeQuery();
            status=rs.next();
            
        }catch(ClassNotFoundException | SQLException e){}
        finally
        {
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }catch(SQLException e){}
            }
            if(pst!=null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException e){}
            }
            if(rs!=null)
            {
                try{
                    rs.close();
                }catch(SQLException e){}
            }
            
        }
        return status;
    }
    public static boolean wardenvalidation(String id, String pass)
    {
        boolean status = false;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String url = "jdbc:mysql://localhost:3306/HMC";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "rgukt123";
        
        try
        {
            Class.forName(driver);
            conn=DriverManager.getConnection(url, userName, password);
            pst=conn.prepareCall("select * from wardensignupdata where hostel=? and pass=?");
            pst.setString(1, id);
            pst.setString(2, pass);
            rs=pst.executeQuery();
            status=rs.next();
            
        }catch(ClassNotFoundException | SQLException e){}
        finally
        {
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }catch(SQLException e){}
            }
            if(pst!=null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException e){}
            }
            if(rs!=null)
            {
                try{
                    rs.close();
                }catch(SQLException e){}
            }
            
        }
        return status;
    }
    public static boolean managervalidation(String id, String pass)
    {
        boolean status = false;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String url = "jdbc:mysql://localhost:3306/HMC";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "rgukt123";
        
        try
        {
            Class.forName(driver);
            conn=DriverManager.getConnection(url, userName, password);
            pst=conn.prepareCall("select * from managersignupdata where mess=? and pass=?");
            pst.setString(1, id);
            pst.setString(2, pass);
            rs=pst.executeQuery();
            status=rs.next();
            
        }catch(ClassNotFoundException | SQLException e){}
        finally
        {
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }catch(SQLException e){}
            }
            if(pst!=null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException e){}
            }
            if(rs!=null)
            {
                try{
                    rs.close();
                }catch(SQLException e){}
            }
            
        }
        return status;
    }
     public static boolean chairmanvalidation(String id, String pass)
    {
        boolean status = false;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String url = "jdbc:mysql://localhost:3306/HMC";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "rgukt123";
        
        try
        {
            Class.forName(driver);
            conn=DriverManager.getConnection(url, userName, password);
            pst=conn.prepareCall("select * from chairmansignupdata where name=? and pass=?");
            pst.setString(1, id);
            pst.setString(2, pass);
            rs=pst.executeQuery();
            status=rs.next();
            
        }catch(ClassNotFoundException | SQLException e){}
        finally
        {
            if(conn!=null)
            {
                try
                {
                    conn.close();
                }catch(SQLException e){}
            }
            if(pst!=null)
            {
                try
                {
                    pst.close();
                }
                catch(SQLException e){}
            }
            if(rs!=null)
            {
                try{
                    rs.close();
                }catch(SQLException e){}
            }
            
        }
        return status;
    }
}
