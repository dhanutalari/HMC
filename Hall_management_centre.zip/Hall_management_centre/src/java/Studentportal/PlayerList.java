/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Studentportal;

/**
 *
 * @author student
 */
public class PlayerList {
    
    Player start,end;
    void insert(String id,String email,String pass)
    {
        Player element=new Player(id,email,pass);
        if(start==null)
        {
            start=element;
            end=element;
        }
        else
        {
            end.next=element;
            end=element;
        }
    }
    int search(String pass)
    {
        int flag=0;
        Player current=start;
        while(current!=null)
        {
            if(current.pass.equals(pass))
            {
                flag=1;
            }
            current=current.next;
        }
        return flag;
    }
    int searchid(String id)
    {
        int flag=0;
        Player current=start;
        while(current!=null)
        {
            if(current.id.equals(id))
            {
                flag=1;
            }
            current=current.next;
        }
        return flag;
    }
    
    
}
