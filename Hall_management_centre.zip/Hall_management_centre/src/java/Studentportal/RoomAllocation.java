/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Studentportal;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author student
 */
public class RoomAllocation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session=request.getSession(false);
        
       
        String sid=(String) session.getAttribute("id");
        String fname=request.getParameter("fname");
        String lname=request.getParameter("lname");
        String room=request.getParameter("room");
        String mess=request.getParameter("mess");
        String hostel=request.getParameter("hostel");
        String mail=request.getParameter("mail");
        ResultSet rs=null;
       
        if(session!=null)
        {
            session.setAttribute("hostel", hostel);
            session.setAttribute("mess", mess);
        }
        try
        {
            
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/HMC","root","rgukt123");
                PreparedStatement ps=con.prepareStatement("insert into allocationdata (id,firstname,lastname,hostel,roomno,mess,email) values(?,?,?,?,?,?,?)");
                PlayerList obj=get();
                int t=obj.search(sid);
                PrintWriter outp = response.getWriter();
                outp.println("Hello All");
                if(t==0)
                {
                    try
                    {
                        
                         outp.println("Hello roomstatus");
                            Class.forName("com.mysql.jdbc.Driver");
                            Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/HMC", "root", "rgukt123");
                            PreparedStatement p=co.prepareStatement("select id from roomstatus where roomno=?");
                            p.setString(1, room);
                            rs=p.executeQuery();
                            outp.println("Hello next");
                            String hid=rs.getString("id");
                            outp.println("Hello All+"+ hid.isEmpty());
                            PreparedStatement p1=co.prepareStatement("update roomstatus set id=? where roomno=?");
                            p1.setString(1, sid);
                            p1.setString(2, room);
                            outp.println("Hello bro "+hid);
                            
                            if(!(rs.next()))
                            {
                                ps.setString(1, sid);
                                ps.setString(2, fname);
                                ps.setString(3, lname);
                                ps.setString(4, hostel);
                                ps.setString(5, room);
                                ps.setString(6, mess);
                                ps.setString(7, mail);
                                ps.executeUpdate();
                                
                                p1.executeUpdate();
                                RequestDispatcher rd=request.getRequestDispatcher("/StudentPortal/Studentportal.jsp");
                                rd.forward(request, response);
                            }
                            else
                            {
                                outp.println("Enter other vacant rooms ");
                                RequestDispatcher rd=request.getRequestDispatcher("/Hall_management_centre/StudentPortal/RoomAllocation.jsp");
                                rd.include(request, response);
                            }
                        
                    }catch(Exception e){}
                }
                else
                {
                    outp.println("Already registered");
                    RequestDispatcher rd=request.getRequestDispatcher("/StudentPortal/Studentportal.jsp");
                    rd.include(request, response);
                }
            
        }catch(Exception e){}
        
        
        
        
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RoomAllocation</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RoomAllocation at " + request.getContextPath()+"hii Dhanu" + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    static PlayerList get() {
         
            PlayerList ind=new PlayerList();
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/HMC", "root", "rgukt123");
                PreparedStatement ps=con.prepareStatement("select *from allocationdata");
                ResultSet rs=ps.executeQuery();
                while(rs.next())
                {
                    String id = rs.getString("id");
                    String fname=rs.getString("firstname");
                    String lname=rs.getString("lastname");
                    ind.insert(id,fname,lname);
                }
                
            }catch(Exception e){}
           return ind;
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
