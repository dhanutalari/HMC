/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Studentportal;

/**
 *
 * @author student
 */
public class Player {
    String id;
    String email;
    String pass;
    Player next;
    Player(String id,String email,String pass)
    {
        this.id=id;
        this.email=email;
        this.pass=pass;
        this.next=null;
    }
    Player() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public String toString()
    {
        return id+"--"+email+"--"+pass;
    }
    void insert(String id, String email, String pass) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
